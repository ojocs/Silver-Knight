var demo = {}, centerX = 1500/2, centerY = 1000/2, knight, isMoving, isBlink, giant, speed = 6;
demo.state0 = function(){};
demo.state0.prototype = {
    preload: function(){
        game.load.spritesheet('knight', 'assets/Silver Knight Spritesheet.png', 185, 216);
        game.load.spritesheet('teleport', 'assets/Teleportation Spritesheet.png', 180, 180);
        game.load.spritesheet('giant', 'assets/Giant Walking Spritesheet.png', 345, 600);
        game.load.image('background', 'assets/Level 1 Background.png', 1000, 1500);
    },
    create: function(){
        //Initiate game physics
        game.physics.startSystem(Phaser.Physics.ARCADE);
        
        //Game screen will adjust with the window size
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        
        //Loads Background
        var background = game.add.sprite(0, 0, 'background');
        
        //Add Silver Knight
        knight = game.add.sprite(centerX, centerY, 'knight');
        knight.anchor.setTo(0.5, 0.5);
        game.physics.enable(knight);
        knight.body.collideWorldBounds = true;
        knight.animations.add('stand', [0, 1]);
        knight.animations.add('walk', [3, 2]);
        knight.animations.add('teleport', [4, 5, 6, 7, 8, 9]);
        
        //Add Giant
        giant = game.add.sprite(centerX, centerY, 'giant');
        giant.anchor.setTo(0.5, 0.5);
        game.physics.enable(giant);
        giant.body.gravity.y = 400;
        giant.body.collideWorldBounds = true;
        giant.animations.add('walk', [0, 1, 2, 3]);
    },
    update: function(){
        isMoving = false;
        var isRight;
        isBlink = false;
        // Move RIGHT
        if(game.input.keyboard.isDown(Phaser.Keyboard.RIGHT)){
            knight.x += speed;
            isRight = true;
            isMoving = true;
        }
        if(game.input.keyboard.isDown(Phaser.Keyboard.LEFT)){
            knight.x -= speed;
            isRight = false;
            isMoving = true;
        }
        if(game.input.keyboard.isDown(Phaser.Keyboard.UP)){
            knight.y -= speed;
            isMoving = true;
        }
        if(game.input.keyboard.isDown(Phaser.Keyboard.DOWN)){
            knight.y += speed;
            console.log(knight.y);
            if(knight.y > 805){ //Keeps Di from going above the road
                knight.y = 805;
            };
            isMoving = true;
        }
        if(game.input.keyboard.isDown(Phaser.KeyCode.SPACEBAR)){
            isBlink = true;
            knight.animations.play('teleport', 15, true);
        }
        
        if (isRight){
            knight.scale.setTo(1, 1); //Make sure he's facing to the right
        }
        else if(isRight == false){
            knight.scale.setTo(-1, 1); //Make sure he's facing to the right
        }
        
        if (isMoving && isBlink == false){
            knight.animations.play('walk', 5, true);
        }
        else if(isMoving == false && isBlink == false){
            knight.animations.play('stand', 5, true);
        }
        
        // Giant AI
        var giantMoves = false
        var distanceFromBoss = giant.body.center.x - knight.body.x;
        if (giant.y > 805){
            giant.y = 805;
        };
        if (distanceFromBoss > 30) {
            giant.body.velocity.x = -100;
            giant.scale.setTo(1, 1); // Turns left
            giantMoves = true;
        }
        else if (distanceFromBoss < (-1 * 30)) {
            giant.body.velocity.x = 100;
            giant.scale.setTo(-1, 1); //Turns right
            giantMoves = true;
        }
        else {
            giant.body.velocity.x = 0;
            giantMoves = false;
            giant.animations.stop(null, true);
        }
        if (giantMoves){
            giant.animations.play('walk', 3, true);
        }
    },
};