<?xml version="1.0" encoding="UTF-8"?>
<tileset name="towerTile" tilewidth="10" tileheight="10" tilecount="256" columns="32">
 <image source="towerTile.png" width="320" height="80"/>
</tileset>
