var tutorial = {
    preload: preload,
    create: create,
    update: update
}

var demo = {};
var vel = 600, outline, movementTested = false, skipButton;

function preload(){
        game.physics.startSystem(Phaser.Physics.ARCADE); // Redundant since it's already been called in state0
        
        //preload knight
        preloadKnight();
        
        //Buttons
        game.load.image('skipButton', 'assets/Tutorial/Skip Tutorial Button.png');        
        
        //Preload tilemap
        game.load.tilemap('test', 'assets/tutorial/tutorial.json', null, Phaser.Tilemap.TILED_JSON);
        game.load.image('backgroundTile', 'assets/tutorial/backgroundTile.png'); // Key must match tileset names
        game.load.image('ltWindowTile', 'assets/tutorial/Left Window.png');
        game.load.image('rtWindowTile', 'assets/tutorial/Right Window.png');
        game.load.image('groundTile', 'assets/tutorial/groundTile.png');
        game.load.image('towerTile', 'assets/tutorial/towerTile.png');
        game.load.image('towerWindow', 'assets/tutorial/Tower Window.png');
        game.load.image('outlineTile', 'assets/tutorial/outlineTile.png');
}

function create(){
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;

    game.physics.startSystem(Phaser.Physics.ARCADE);
    
    var map = game.add.tilemap('test');
    map.addTilesetImage('backgroundTile');
    map.addTilesetImage('ltWindowTile');
    map.addTilesetImage('rtWindowTile');
    map.addTilesetImage('groundTile');
    map.addTilesetImage('towerTile');
    map.addTilesetImage('towerWindow');
    map.addTilesetImage('outlineTile');
        
    // Add tilemap layers
    map.createLayer('background');
    map.createLayer('ltWindow');
    map.createLayer('rtWindow');
    map.createLayer('ground');
    map.createLayer('tower');
    map.createLayer('towerWindow');
    outline = map.createLayer('outline');
    
    //Allows things to collide with the outline layer
    map.setCollisionBetween(1332, 1360, true, 'outline');
        
    //Add button

//    skipButton = game.add.button(centerX+250, 60, 'skipButton', startLevelSelect, this);
//    skipButton.anchor.setTo(0.5, 0.5);
//    skipButton.scale.setTo(0.8, 0.8);
//    skipButton.inputEnabled = true;
    
    //create knight
    createKnight(0);
}
 
function update() {
    //Just change 'adam' to whatever sprite's name that you want to collide
    game.physics.arcade.collide(knight, outline);
        
    //update knight
    updateKnight();
//    if(skipButton.input.pointerOver())
//        teleMode = false;
        
    //testMovement();
}

//WASD movement
function testMovement(){
    game.add.text(600, 50, 'Try to move by pressing the WASD keys', {
                fontSize: '50px',
                fill: '#FFFFFF'
            });
        if (moveBinds.upW.isDown){
            adam.body.velocity.y = -vel;
            movementTested = true;
        }
        else if (moveBinds.downS.isDown){
            adam.body.velocity.y = vel;
            movementTested = true;
        }
        else{
            adam.body.velocity.y = 0;
        }
        
        
        if (moveBinds.leftA.isDown){
            adam.body.velocity.x = -vel;
            movementTested = true;
        }
        else if (moveBinds.rightD.isDown){
            adam.body.velocity.x = vel;
            movementTested = true;
        }
        else{
            adam.body.velocity.x = 0;
        }
        
    
}


function returnToMain(){
    game.state.start('startScreen')
}