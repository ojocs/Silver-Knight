<?xml version="1.0" encoding="UTF-8"?>
<tileset name="towerWindow" tilewidth="10" tileheight="10" tilecount="256" columns="16">
 <image source="Tower Window.png" width="160" height="160"/>
</tileset>
