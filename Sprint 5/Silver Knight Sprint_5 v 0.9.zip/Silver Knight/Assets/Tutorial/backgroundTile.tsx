<?xml version="1.0" encoding="UTF-8"?>
<tileset name="backgroundTile" tilewidth="10" tileheight="10" tilecount="512" columns="32">
 <image source="backgroundTile.png" width="320" height="160"/>
</tileset>
