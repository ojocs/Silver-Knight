<?xml version="1.0" encoding="UTF-8"?>
<tileset name="backgroundTile" tilewidth="40" tileheight="40" tilecount="32" columns="8">
 <image source="backgroundTile.png" width="320" height="160"/>
</tileset>
