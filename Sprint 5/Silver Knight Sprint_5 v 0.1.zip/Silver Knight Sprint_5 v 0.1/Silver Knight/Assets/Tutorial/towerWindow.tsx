<?xml version="1.0" encoding="UTF-8"?>
<tileset name="towerWindow" tilewidth="40" tileheight="40" tilecount="16" columns="4">
 <image source="Tower Window.png" width="160" height="160"/>
</tileset>
