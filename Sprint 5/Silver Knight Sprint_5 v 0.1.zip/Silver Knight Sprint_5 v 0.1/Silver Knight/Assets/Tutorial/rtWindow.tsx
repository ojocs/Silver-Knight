<?xml version="1.0" encoding="UTF-8"?>
<tileset name="rtWindow" tilewidth="40" tileheight="40" tilecount="600" columns="20">
 <image source="Right Window.png" width="800" height="1200"/>
</tileset>
