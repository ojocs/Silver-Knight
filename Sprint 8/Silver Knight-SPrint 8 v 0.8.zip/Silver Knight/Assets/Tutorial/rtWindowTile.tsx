<?xml version="1.0" encoding="UTF-8"?>
<tileset name="rtWindowTile" tilewidth="10" tileheight="10" tilecount="9600" columns="80">
 <image source="Right Window.png" width="800" height="1200"/>
</tileset>
