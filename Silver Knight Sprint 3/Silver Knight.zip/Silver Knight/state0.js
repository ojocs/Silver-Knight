var demo = {}, centerX = 2000/2, centerY = 1000/2, knight;

//Giant Variables
var giant;
var giantDistThreshold = 30;
var giantSpeed = 50;

var moveBinds;
var ground
var antiGroundStuck;//Unused (In Oz's Movement-Tester but hasn't been integrated into this one yet)

//Blink Variables
var blink;
var blinkDist = 20;
var blinkTimer; //Unused

// Momentum
var speed, drag = 10, vertSpeed = 0;

var health = 6; //Knight has 6 lives
//var change = game.rnd.integerInRange(1, 3);

demo.state0 = function(){};
demo.state0.prototype = {
    preload: function(){
        game.load.spritesheet('knight', 'assets/Silver Knight Spritesheet.png', 129, 150);
        game.load.spritesheet('giant', 'assets/Giant Walking Spritesheet.png', 345, 600);
        game.load.image('background', 'assets/Level 1 Background.png');
        game.load.image('heart', 'assets/heart 100.png');
        game.load.image('half_heart', 'assets/half heart 100.png');
    },
    create: function(){
        //Initiate game physics
        game.physics.startSystem(Phaser.Physics.ARCADE);
        
        //Game screen will adjust with the window size
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        
        //Load Background
        var background = game.add.sprite(0, 0, 'background');
        
        //Add Silver Knight
        knight = game.add.sprite(0, 0, 'knight');
        knight.anchor.setTo(0.5, 0.5);
        game.physics.enable(knight);
        knight.body.gravity.y = 200;
        knight.body.collideWorldBounds = true;
        knight.animations.add('stand', [0, 1]);
        knight.animations.add('walk', [3, 2]);
        knight.animations.add('teleport', [4, 5, 6, 7, 8, 9]);
        
        //Add Giant
        giant = game.add.sprite(centerX, centerY, 'giant');
        giant.anchor.setTo(0.5, 0.5);
        game.physics.enable(giant);
        giant.body.gravity.y = 400;
        giant.body.collideWorldBounds = true;
        giant.animations.add('walk', [0, 1, 2, 3]);
        
        //Health Display
        heart1 = game.add.image(10, 10,'heart');
        heart2 = game.add.image(125, 10,'heart');
        heart3 = game.add.image(240, 10,'heart');
        
        //Movement Key Binds
        moveBinds = game.input.keyboard.addKeys({
            'upW': Phaser.KeyCode.W,
            'downS': Phaser.KeyCode.S,
            'leftA': Phaser.KeyCode.A,
            'rightD': Phaser.KeyCode.D
        });
        
        // Shift for blink | CHANGE TO LEFT SHIFT
        blink = game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);
        
        //Mouse click for teleportation
        game.input.mouse.capture = true;
      //  antiGroundStuck = knight.body.height + ground.body.height + knight.body.height / 16; //Prevents the player from teleporting into the ground

    },
    update: function(){
        
        //Knight loses health when hit by the giant
        game.physics.arcade.overlap(knight, giant, this.knightDamage);
        
        //------------------REGULAR MOVEMENT--------------------------//
        //Move Left and Right
        if (moveBinds.leftA.isDown) {
            knight.body.velocity.x = -400;
            knight.scale.setTo(-1, 1); //Knight faces left
            knight.animations.play('walk', 5, true);
        }
        else if (moveBinds.rightD.isDown) {
            knight.body.velocity.x = 400;
            knight.scale.setTo(1, 1); //Knight faces right
            knight.animations.play('walk', 5, true);
        }
        else {
            knight.animations.play('stand', 5, true);
        }
        
        //Jump ------------NEEDS FIXING: touching.down
        if (moveBinds.upW.isDown && knight.body.touching.down) {
            knight.body.velocity.y = -220;
        }
        
        //Stop moving left/right ------------NEEDS FIXING: touching.down
        if (moveBinds.downS.isDown && knight.body.touching.down) {
            knight.body.velocity.x = 0;
        }
        
        // Horizontal momentum kept and slowed down with drag
        speed = knight.body.velocity.x;
        if (speed > 0) {
            knight.body.velocity.x = Math.abs(speed - drag);
        }
        else if (speed < 0) {
                knight.body.velocity.x = speed + drag;
        }
        else {
            knight.body.velocity.x = 0;
        }
        //------------------END REGULAR MOVEMENT--------------------------//

        //------------------- //TELEPORTING//-----------------------//
        
  /*     //Long teleportation
        if (game.input.activePointer.leftButton.isDown) {
                cursorTele();
        }*/

        //Blink
        if (blink.isDown) {
            this.blinkTele();
        } 
        
        //Giant AI
        var distanceFromBoss = giant.body.center.x - knight.body.x;
        if (distanceFromBoss > 30) {
            giant.body.velocity.x = -100;
            giant.scale.setTo(1, 1); // Turns left
            giant.animations.play('walk', 3, true);
        }
        else if (distanceFromBoss < (-1 * 30)) {
            giant.body.velocity.x = 100;
            giant.scale.setTo(-1, 1); //Turns right
            giant.animations.play('walk', 3, true);
        }
        else {
            giant.body.velocity.x = 0;
            giantMoves = false;
            giant.animations.stop(null, true);
        }
    },
    
    //Long teleportation
    /*cursorTele: function(){
        
    }*/


    //Blink
/*    blinkTele: function() {

    } */
    
    //Teleport
    /*teleport: function() {
        
    }*/
    
    //Player loses health
    knightDamage: function() {
        health -= 1;

        if (health == 5) {
            heart3.kill();
            heart3 = game.add.image(240, 10,'half_heart');
        }
        else if (health == 4) {
            heart3.kill();
        }
        else if (health == 3) {
            heart2.kill();
            heart2 = game.add.image(125,10,'half_heart');
        }
        else if (health == 2) {
            heart2.kill();
        }
        else if (health == 1) {
            heart1.kill();
            heart1 = game.add.image(10,10,'half_heart');
        } 
        else if (health <= 0) {
            heart1.kill();
            game.add.text(150, 250, 'GAME OVER', {
                fontSize: '90px',
                fill: '#000'
            });
        }
    }
};