var state0 = {
    preload: preload,
    create: create,
    update: update
}

function preload() {
    game.load.spritesheet('knight', 'assets/Silver Knight Spritesheet.png', 129, 150);
    game.load.spritesheet('giant', 'assets/Giant Walking Spritesheet.png', 345, 600);
    game.load.image('background', 'assets/Level 1 Background.png');
    game.load.image('heart', 'assets/heart 100.png');
    game.load.image('half_heart', 'assets/half heart 100.png');
}

var demo = {},
    centerX = 2000 / 2,
    centerY = 1000 / 2,
    knight;

//Giant Variables
var giant;
var giantDistThreshold = 30;
var giantSpeed = 50;
var giantMoves;

var moveBinds;
var ground;
var antiGroundStuck;

//Blink Variables
var blink;
var blinkDist = 60;
var blinkTimer; //Unused

// Momentum
var speed, drag = 10;
var vertSpeed = 0;

var health = 6; //Knight has 6 lives
//var change = game.rnd.integerInRange(1, 3);

function create() {
    //Initiate game physics
    game.physics.startSystem(Phaser.Physics.ARCADE);

    //Game screen will adjust with the window size
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;

    //Load Background
    var background = game.add.sprite(0, 0, 'background');

    //Ground
    ground = game.world.height;

    //Add Giant
    giant = game.add.sprite(centerX, centerY, 'giant');
    giant.anchor.setTo(0.5, 0.5);
    game.physics.enable(giant);
    giant.body.gravity.y = 400;
    giant.body.collideWorldBounds = true;
    giant.animations.add('walk', [0, 1, 2, 3]);

    //Health Display
    heart1 = game.add.image(10, 10, 'heart');
    heart2 = game.add.image(125, 10, 'heart');
    heart3 = game.add.image(240, 10, 'heart');

    //Add Silver Knight
    knight = game.add.sprite(0, 0, 'knight');
    knight.anchor.setTo(0.5, 0.5);
    game.physics.enable(knight);
    knight.body.bounce.y = 0.1;
    knight.body.gravity.y = 330;
    knight.body.collideWorldBounds = true;
    knight.animations.add('stand', [0, 1]);
    knight.animations.add('walk', [3, 2]);
    knight.animations.add('teleport', [4, 5, 6, 7, 8, 9]);

    //Movement Key Binds
    moveBinds = game.input.keyboard.addKeys({
        'upW': Phaser.KeyCode.W,
        'downS': Phaser.KeyCode.S,
        'leftA': Phaser.KeyCode.A,
        'rightD': Phaser.KeyCode.D
    });

    // Shift for blink | CHANGE TO LEFT SHIFT
    blink = game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    //Mouse click for teleportation
    game.input.mouse.capture = true;
    antiGroundStuck = 150 / 16; //Prevents the player from teleporting into the ground

}

function update() {
    //make Knight visible
    knight.visible = true;
    //Knight loses health when hit by the giant
    game.physics.arcade.overlap(knight, giant, this.knightDamage);

    //------------------REGULAR MOVEMENT--------------------------//
    //Move Left and Right
    if (moveBinds.leftA.isDown) {
        knight.body.velocity.x = -400;
        knight.scale.setTo(-1, 1); //Knight faces left
        knight.animations.play('walk', 5, true);
    } else if (moveBinds.rightD.isDown) {
        knight.body.velocity.x = 400;
        knight.scale.setTo(1, 1); //Knight faces right
        knight.animations.play('walk', 5, true);
    } else {
        knight.animations.play('stand', 5, true);
    }

    //Jump ------------NEEDS FIXING: touching.down->->->->Only works with actual ground and platforms, not world bounds. So make ground and //platform objects
    if (moveBinds.upW.isDown && knight.body.touching.down) {
        knight.body.velocity.y = -220;
    }

    //Stop moving left/right ------------NEEDS FIXING: touching.down->->->->->Ditto^^^
    if (moveBinds.downS.isDown && knight.body.touching.down) {
        knight.body.velocity.x = 0;
    }

    // Horizontal momentum kept and slowed down with drag
    speed = knight.body.velocity.x;
    if (speed > 0) {
        knight.body.velocity.x = Math.abs(speed - drag);
    } else if (speed < 0) {
        knight.body.velocity.x = speed + drag;
    } else {
        knight.body.velocity.x = 0;
    }
    //------------------END REGULAR MOVEMENT--------------------------//

    //------------------- //TELEPORTING//-----------------------//

    //Long teleportation
    if (game.input.activePointer.leftButton.isDown) {
        cursorTele();
    }

    //Blink
    if (blink.isDown) {
        blinkTele();
    }

    //Giant AI
    var distanceFromBoss = giant.body.center.x - knight.body.x;
    if (distanceFromBoss > 30) {
        giant.body.velocity.x = -100;
        giant.scale.setTo(1, 1); // Turns left
        giant.animations.play('walk', 3, true);
    } else if (distanceFromBoss < (-1 * 30)) {
        giant.body.velocity.x = 100;
        giant.scale.setTo(-1, 1); //Turns right
        giant.animations.play('walk', 3, true);
    } else {
        giant.body.velocity.x = 0;
        giantMoves = false;
        giant.animations.stop(null, true);
    }

}


//Long teleportation
function cursorTele() {
    var newX = game.input.activePointer.x;
    var newY = game.input.activePointer.y;
    //to prevent getting stuck in ground
    if (newY >= game.world.height - antiGroundStuck)
        newY = game.world.height - antiGroundStuck;
    teleport(newX, newY);
}


//Blink
function blinkTele() {
    var newX = knight.body.x;
    var newY = knight.body.y;
    //if moving right add 10 to current pos
    if (moveBinds.rightD.isDown) {
        newX += blinkDist;
    }
    //else subtract 10
    else if (moveBinds.leftA.isDown) {
        newX -= blinkDist;
    }

    //if moving up subtract 10 to current pos
    if (moveBinds.upW.isDown) {
        newY -= blinkDist;
    }
    //else add 10
    else if (moveBinds.downS.isDown) {
        newY += blinkDist;
        //check to not go below ground. Account for height of world and height of ground
        if (newY >= game.world.height - antiGroundStuck)
            newY = game.world.height - antiGroundStuck; //above or exactly at ground height
    }

    //        blinkTick--;

    //reset timer and tick if out of ticks
    //if(){
    //knight.body.y = 300;
    //            this.blinkTimer.destroy();
    //            blinkTimer = game.time.create(false);
    //            blinkTimer.start();
    //            blinkTick = 5;
    //      }
    teleport(newX, newY);
}

//Teleport
function teleport(newX, newY) {
    knight.body.x = newX;
    knight.body.y = newY;
    //for teleporting to look like teleporting and not a dash
    knight.visible = false;
    game.time.events.add(Phaser.Time.SECOND, update, this);
}

//Player loses health
function knightDamage() {
    health -= 1;

    if (health == 5) {
        heart3.kill();
        heart3 = game.add.image(240, 10, 'half_heart');
    } else if (health == 4) {
        heart3.kill();
    } else if (health == 3) {
        heart2.kill();
        heart2 = game.add.image(125, 10, 'half_heart');
    } else if (health == 2) {
        heart2.kill();
    } else if (health == 1) {
        heart1.kill();
        heart1 = game.add.image(10, 10, 'half_heart');
    } else if (health <= 0) {
        heart1.kill();
        game.add.text(150, 250, 'GAME OVER', {
            fontSize: '90px',
            fill: '#000'
        });
    }
}
