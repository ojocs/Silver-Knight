var tutorial = {
    preload: preload,
    create: create,
    update: update
}

var demo = {};
var backButton, skipButton;

function preload(){
    game.load.image('backButton', 'assets/Tutorial/Continue Button.png');
    game.load.image('skipButton', 'assets/Tutorial/Skip Button.png');
}

function create(){
    var style = { font: "100px Arial", fill: "#ff0044", align: "center" };
    var text = game.add.text(game.world.centerX, game.world.centerY, "TUTORIAL", style);
    text.anchor.set(0.5);
    
    backButton = game.add.button(100, 100, 'backButton');
    backButton.anchor.setTo(0.5, 0.5);
    backButton.scale.setTo(-1, 1);
    backButton.inputEnabled = true;
    backButton.onInputUp.add(returnToStart, this);
    
    skipButton = game.add.button(1800, 100, 'skipButton');
    skipButton.anchor.setTo(0.5, 0.5);
    skipButton.scale.setTo(0.5, 0.5);
    skipButton.inputEnabled = true;
    skipButton.onInputUp.add(startGame, this);
}

function update(){}

function returnToStart(){
    game.state.start('startScreen')
}