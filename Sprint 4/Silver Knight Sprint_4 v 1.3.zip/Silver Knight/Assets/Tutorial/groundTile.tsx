<?xml version="1.0" encoding="UTF-8"?>
<tileset name="groundTile" tilewidth="40" tileheight="40" tilecount="16" columns="8">
 <image source="groundTile.png" width="320" height="80"/>
</tileset>
