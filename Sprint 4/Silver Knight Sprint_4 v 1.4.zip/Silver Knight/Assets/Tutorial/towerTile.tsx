<?xml version="1.0" encoding="UTF-8"?>
<tileset name="towerTile" tilewidth="40" tileheight="40" tilecount="16" columns="8">
 <image source="towerTile.png" width="320" height="80"/>
</tileset>
