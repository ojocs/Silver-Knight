<?xml version="1.0" encoding="UTF-8"?>
<tileset name="outline" tilewidth="40" tileheight="40" tilecount="12" columns="3">
 <image source="outlineTile.png" width="120" height="160"/>
</tileset>
