<?xml version="1.0" encoding="UTF-8"?>
<tileset name="outlineTile" tilewidth="10" tileheight="10" tilecount="192" columns="12">
 <image source="outlineTile.png" width="120" height="160"/>
</tileset>
